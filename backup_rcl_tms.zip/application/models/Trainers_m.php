<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

/**
* 
*/
class Trainers_m extends CI_Model
	{

		public function save_trainer()
		{	
			
			$_POST['trainers_signature'] = $_FILES['trainers_signature']['name'];
			$name = $_FILES['trainers_signature']['name'];
			$sp =$_FILES['trainers_signature']['tmp_name'];
			
			unset($_POST['submit']);
			$this->db->insert('trainers',$_POST);
			
			$id=$this->db->insert_id();
			$dp ='images/trainers/'.$id.'_'.$name;
			move_uploaded_file($sp,$dp);

			return 1;

		}

		public function trainers($limit=null,$offset=null)
		{
			return $this->db->get('trainers',$limit,$offset)->result();
		}

		public function single_trainer($id)
		{
			return $this->db->get_where('trainers', array('id' => $id))->row();
		}

		public function edit_trainer($id)
		{
			return $this->db->get_where('trainers', array('id' => $id))->row();
		}

		public function update_trainer($id)
		{	
			unset($_POST['submit']);

			$check=$this->db->query("select id,trainers_email from trainers where trainers_email='".$_POST['trainers_email']."' and id != ".$id)->num_rows();
			
			$_POST['trainers_signature'] = $_FILES['trainers_signature']['name'];
			$name = $_FILES['trainers_signature']['name'];
			$sp =$_FILES['trainers_signature']['tmp_name'];
			
			if ($_FILES['trainers_signature']['name']==''){ //if not select new image
				$_POST['trainers_signature'] = $_POST['signature'];
			}
			else{
				$dp ='images/trainers/'.$id.'_'.$name;
				move_uploaded_file($sp,$dp);
			}

			if ($check==0) {
				unset($_POST['signature']);
				$this->db->where('id', $id);
				$this->db->update('trainers',$_POST);
				return 1;
			}
			else{
				return 0;
			}
			
		}

		public function delete_trainer($id)
		{
			
			$result = $this->single_trainer($id);
			if ($result->trainers_signature) {
				unlink('images/trainers/'.$id.'_'.$result->trainers_signature); 
			}
			$this->db->where('id', $id);
			$this->db->delete('trainers');
			return 1;
		}

		// =====================end Trainers===================
	}

?>